﻿using CSR.Budget.Entity.Models.Requests;
using CSR.Budget.Entity.Models.Responses;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSR.Budget.DataAccessLayer
{
    public static class Utilities
    {
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
        public static List<T> ConvertDataTable<T>(this DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        public static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
        public static DataTable ConvertToDatatable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for(int i = 0 ; i < props.Count ; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;        
        }
        public static async Task<HttpResponseMessage> ExecuteAuthentication(string url, string head, string body)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(url);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Add("Authorization", head);
                var httpContent = new StringContent(body, Encoding.UTF8, "application/json");
                return await client.PostAsync("", httpContent);
            }
        }

        public static async Task<HttpResponseMessage> ExecutePostAsync(string relativeUri, string content)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(relativeUri);

                client.DefaultRequestHeaders.Accept.Clear();

                var httpContent = new StringContent(content, Encoding.UTF8, "application/json");

                return await client.PostAsync("", httpContent).ConfigureAwait(true);
            }
        }

        public static async Task<T> ResultToPocoAsync<T>(HttpResponseMessage results)
        {
            var responseData = await results.Content.ReadAsStringAsync().ConfigureAwait(true);
            return JsonConvert.DeserializeObject<T>(responseData);
        }

        public static DataTable ListToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static T DeserializeJson<T>(string json)
        {
            try
            {
                Newtonsoft.Json.JsonSerializer jsonSer = new Newtonsoft.Json.JsonSerializer();
                var test = jsonSer.Deserialize<T>(new Newtonsoft.Json.JsonTextReader(new StringReader(json)));
                return test;
            }
            catch (Exception)
            {
                return default(T);
            }
        }
        public static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
 




        public static async Task<HttpResponseMessage> ExecutePostWithoutIdentityAsync<T>(string relativeUri, T postContent, string accessToken)
        {
            return await HandlePostWithoutIdentity(relativeUri, postContent.ToString(), accessToken);
        }

        private static async Task<HttpResponseMessage> HandlePostWithoutIdentity(string relativeUri, string content, string accessToken)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(relativeUri);

                client.DefaultRequestHeaders.Accept.Clear();

                client.Timeout = TimeSpan.FromSeconds(185);

                client.DefaultRequestHeaders.Add("authorization", accessToken);

                var httpContent = new StringContent(content, Encoding.UTF8, "application/json");

                return await client.PostAsync("", httpContent);
            }
        }
        public static async Task<T> ResultToPoco<T>(HttpResponseMessage results)
        {
            using (var responseStream = await results.Content.ReadAsStreamAsync().ConfigureAwait(true))
            {
                var jsonMessage = await new StreamReader(responseStream).ReadToEndAsync().ConfigureAwait(true);

                return JsonConvert.DeserializeObject<T>(jsonMessage);
            }
        }

        //****
        public static async Task<IdentitiesResponse> CreateIdentityAsync(IdentitiesRequest identitiesRequest, DocumentTypesignzy docType, string signzypath, string signzyusername, string signzypwd)
        {
            var jsonInput = JsonConvert.SerializeObject(identitiesRequest);

            var response = await HandleIdentityPost(string.Empty, jsonInput, docType,signzypath, signzyusername, signzypwd);

            return response;
        }

        //****
        private static async Task<IdentitiesResponse> HandleIdentityPost(string relativeUri, string content, DocumentTypesignzy docType, string signzypath, string signzyusername, string signzypwd)
        {
            using (var client = new HttpClient())
            {
                var res = await RetrieveTokenAsync(signzyusername, signzypwd, signzypath);

                client.BaseAddress = new Uri(signzypath + "/api/v2/patrons/" + res.PatronId + "/identities");

                client.DefaultRequestHeaders.Accept.Clear();

                client.DefaultRequestHeaders.Add("authorization", res.AccessToken);

                //client.Timeout = timeSpan;

                var httpContent = new StringContent(content, Encoding.UTF8, "application/json");

                HttpResponseMessage result = await client.PostAsync("", httpContent).ConfigureAwait(true);

                var response = await result.Content.ReadAsAsync<IdentitiesResponse>().ConfigureAwait(true);

                return response;
            }
        }

        //****
        public static async Task<TokenResponse> RetrieveTokenAsync(string UserName, string Password, string signzypath)
        {
            var userInformation = new StringBuilder();
            userInformation.Append("grant_type=");
            userInformation.Append("password");
            userInformation.Append("&username=");
            userInformation.Append(UserName);
            userInformation.Append("&password=");
            userInformation.Append(Password);
            HttpContent requestContent =
                new StringContent(
                    userInformation.ToString(),
                    Encoding.UTF8,
                    "application/x-www-form-urlencoded");

            using (var client = new HttpClient())
            {
                var response = client.PostAsync(signzypath + "/api/v2/patrons/login", requestContent).Result;

                using (var responseStream = await response.Content.ReadAsStreamAsync())
                {
                    var jsonMessage = new StreamReader(responseStream).ReadToEnd();

                    return (TokenResponse)JsonConvert.DeserializeObject(jsonMessage, typeof(TokenResponse));
                }
            }
        }

        public static async Task<HttpResponseMessage> ExecutePostAsync<T>(string relativeUri, T postContent)
        {
            return await ExecutePostAsync(relativeUri, postContent, TimeSpan.FromSeconds(185)).ConfigureAwait(true);
        }

        public static async Task<HttpResponseMessage> ExecutePostAsync<T>(string relativeUri, T postContent, TimeSpan timeSpan)
        {
            MediaTypeFormatter jsonFormatter = new JsonMediaTypeFormatter();

            HttpContent content = new ObjectContent<T>(postContent, jsonFormatter);

            return await HandlePost(relativeUri, content, timeSpan).ConfigureAwait(true);
        }

        private static async Task<HttpResponseMessage> HandlePost(string relativeUri, HttpContent content, TimeSpan timeSpan)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(relativeUri);

                client.Timeout = timeSpan;

                client.DefaultRequestHeaders.Accept.Clear();

                return await client.PostAsync(relativeUri, content).ConfigureAwait(false);
            }
        }


    }
}
public enum DocumentTypesignzy
{
    individualPan,
    businessPan,
    aadhaar,
    drivingLicence,
    passport,
    voterid,
}