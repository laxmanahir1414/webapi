﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSR.Budget.DataAccessLayer
{
    public class DBHelper
    {
        public string connectionString { get; set; }
        public readonly IConfiguration configuration;

        /// <summary>
        /// Get connection details
        /// </summary>
        public DBHelper(IConfiguration config)
        {
            configuration = config;
            connectionString = configuration.GetConnectionString("DefaultConnection");

        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~DBHelper()
        {
            Dispose(false);
        }

        // Protected implementation of Dispose pattern. 
        protected virtual void Dispose(bool disposing)
        {
            if (!disposing)
            {
                if (disposing)
                {
                    this.Dispose();
                    DisposeManagedResources();
                }

                DisposeUnmanagedResources();
                disposing = true;
            }
        }

        protected virtual void DisposeManagedResources()
        {

        }
        protected virtual void DisposeUnmanagedResources() { }
    }
}
