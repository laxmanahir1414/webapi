﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CSR.Budget.Entity.Models.Responses
{
    public class UilitiesResponse
    {
    }
    public class TokenResponse
    {
        [JsonProperty("id")]
        public string AccessToken { get; set; }

        [JsonProperty("userId")]
        public string PatronId { get; set; }

        [JsonProperty("ttl")]
        public string Ttl { get; set; }

        [JsonProperty("created")]
        public string Created { get; set; }
    }
    public class IdentitiesResponse
    {
        [JsonProperty("type")]
        public string DocType { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("callbackUrl")]
        public string CallbackUrl { get; set; }

        [JsonProperty("images")]
        public List<string> Images { get; set; }

        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }

        [JsonProperty("autoRecognition")]
        public List<string> AutoRecognition { get; set; }

        [JsonProperty("forgeryCheck")]
        public List<string> ForgeryCheck { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("patronId")]
        public string PatronId { get; set; }
    }

}
