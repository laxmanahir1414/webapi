﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSR.Budget.Entity.Models.Responses
{
    public class LoginResponse
    {
        public string Token { get; }

        public DateTime? Expiration { get; }

        public string Msg { get; }

        public LoginResponse(string token, DateTime expiration, string msg)
        {
            Token = token;
            Expiration = expiration;
            Msg = msg;
        }
    }

    public class LoginDBResponse
    {
        public Boolean IsValidUser { get; set; }
        public string Message { get; set; }

    }
}