﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CSR.Budget.Entity.Models.Requests
{
    public class UtilitiesRequest
    {
    }
    [DataContract]
    public class IdentitiesRequest
    {
        [DataMember(Name = "type")]
        public string Type { get; set; }

        [DataMember(Name = "callbackUrl")]
        public string CallBackUrl { get; set; }

        [DataMember(Name = "email")]
        public string EndUserEmailId { get; set; }

        [DataMember(Name = "images")]
        public List<object> Images { get; set; }

    }
}
