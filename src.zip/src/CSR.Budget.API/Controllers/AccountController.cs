﻿using CSR.Budget.Authentication;
using CSR.Budget.Entity.Models.Requests;
using CSR.Budget.Entity.Models.Responses;
using CSR.Budget.Repository.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Reflection.Metadata;

namespace CSR.Budget.API.Controllers
{
    public class AccountController : ControllerBase
    {
        protected readonly IAccountRepository _repository;
        private readonly ILogger _logger;
        private readonly IOptions<GlobalFields> _globalFields;
        private readonly IConfiguration _configuration;

        public AccountController(IConfiguration configuration,IAccountRepository repository, IOptions<GlobalFields> globalFields,ILogger<AccountController> logger)
        {
            _repository = repository;
            _globalFields = globalFields;
            _logger = logger;
            _configuration = configuration;
        }


        [AllowAnonymous]
        [HttpPost("login")]
        //[SwaggerRequestExample(typeof(LoginRequest), typeof(LoginRequestExample))]
        public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginReq loginrequest)
        {
            _logger.LogInformation("Login Request {@Request}", loginrequest);
            LoginResponse result = null;

            try
            {
                LoginDBResponse varresult = await _repository.Login(loginrequest).ConfigureAwait(true);
                if (varresult.IsValidUser == true)
                {
                    var accessToken = new JwtGenerator(_configuration).CreateAccessToken();

                    if (accessToken != null)
                    {
                        result = new LoginResponse(accessToken.Token, accessToken.Expiration, accessToken.Msg);
                    }
                    else {
                        result = new LoginResponse("", DateTime.Now, "Invalid User !");
                    }
                }
                else
                {
                    result = new LoginResponse("", DateTime.Now, "Invalid User !");

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Message for  MCardFamilyLogin() {@Exception}", ex);
                result = new LoginResponse("", DateTime.Now, "Invalid User !");
            }

            return result;

        }

        //[AllowAnonymous]
        //[HttpPost("MCardFamilyforgotPassword")]
        ////[SwaggerRequestExample(typeof(ForgotPasswordRequest), typeof(ForgotPasswordRequestExample))]
        //public async Task<IActionResult> MCardFamilyforgotPassword([FromBody] ForgotPasswordRequest forgotPasswordRequest)
        //{
        //    Log.Information("MCardFamilyforgotPassword Request {@ForgotPasswordRequest}", forgotPasswordRequest);
        //    ForgotPasswordResponse result = new ForgotPasswordResponse();
        //    try
        //    {
        //        result = await _repository.ForgotPasswordAsync(forgotPasswordRequest).ConfigureAwait(true);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error("Exception Message for  MCardFamilyforgotPassword() {@Exception}", ex);
        //    }
        //    Log.Information("MCardFamilyforgotPassword Response {@ForgotPasswordResponse}", result);

        //    return Ok(result);
        //}
    }
}
