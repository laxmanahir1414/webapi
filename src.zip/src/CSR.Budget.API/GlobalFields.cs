﻿namespace CSR.Budget.API
{
    public class GlobalFields
    {
        public string SecurityKey { get; set; }
        public string Port { get; set; }
    }

    public class Appsettings
    {
        public string ImagePath { get; set; }
        public string[] Folder { get; set; }
    }
}
