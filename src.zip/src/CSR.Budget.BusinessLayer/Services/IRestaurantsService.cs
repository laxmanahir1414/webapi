﻿using CSR.Budget.Entity.Models.Responses;

namespace CSR.Budget.BusinessLayer.Services;

public interface IRestaurantsService
{
    Task<Restaurant> GetAsync(Guid id);

    Task<ListResult<Restaurant>> GetAsync(int pageIndex, int itemsPerPage);
}
