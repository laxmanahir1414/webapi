﻿using CSR.Budget.DataAccessLayer;
using CSR.Budget.Entity.Models.Requests;
using CSR.Budget.Entity.Models.Responses;
using CSR.Budget.Repository.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSR.Budget.Repository.concrete
{
    public class AccountRepository : DBHelper, IAccountRepository
    {
        ILogger<AccountRepository> _logger;
        public AccountRepository(IConfiguration config, ILogger<AccountRepository> logger) : base(config)
        {
            _logger = logger;
        }
        public async Task<LoginDBResponse> Login(LoginReq loginRequest)
        {
            LoginDBResponse loginResponse = new LoginDBResponse();
            string strResponse = string.Empty;
            string strMsg = string.Empty;
            try
            {
                    //SqlParameter[] param = { 
                    //new SqlParameter("@pUserName", loginRequest.Email), 
                    //new SqlParameter("@pPassWd", loginRequest.Password),
                    //new SqlParameter("@pMsg",ParameterDirection.Output)
                    //};

                SqlParameter[] param = new SqlParameter[3];
                param[0] = new SqlParameter("@pUserName", loginRequest.Email);
                param[1] = new SqlParameter("@pPassWd", loginRequest.Password);
                param[2] = new SqlParameter("@pMsg", SqlDbType.VarChar,50);
                param[2].Direction = ParameterDirection.Output;

                var result = await SqlHelper.ExecuteNonQueryAsync(connectionString, CommandType.StoredProcedure, "checkValidUser", param);
                strMsg = (string)param[2].Value;

                strResponse = JsonConvert.SerializeObject(result);
                _logger.LogInformation("Get LoginDB Response from Database - " + strResponse);

                if (!string.IsNullOrEmpty(strMsg) && strMsg == "SUCC")
                {
                    //DataTable dt = ds.Tables[0];
                    //if (ds != null && ds.Tables.Count >0 && dt.Rows.Count > 0)
                    //{
                        loginResponse.IsValidUser = true;
                        loginResponse.Message = strMsg;
                    //}
                    //else
                    //{
                    //    loginResponse.IsValidUser = false;
                    //    loginResponse.Message = "Invalid User !";
                    //}
                }
                else
                {
                    loginResponse.IsValidUser = false;
                    loginResponse.Message = "Invalid User !";
                }
            }
            catch (Exception ae)
            {
                _logger.LogError("Exception in Get LoginDB {@Exception}", ae);
            }
            return loginResponse;
        }
    }
}
