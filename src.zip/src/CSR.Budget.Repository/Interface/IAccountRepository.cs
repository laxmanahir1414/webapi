﻿using CSR.Budget.Entity.Models.Requests;
using CSR.Budget.Entity.Models.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSR.Budget.Repository.Interface
{
    public interface IAccountRepository
    {
        Task<LoginDBResponse> Login(LoginReq loginrequest);
    }
}
