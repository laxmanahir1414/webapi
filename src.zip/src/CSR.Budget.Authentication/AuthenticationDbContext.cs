﻿using CSR.Budget.Authentication.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CSR.Budget.Authentication;

public class AuthenticationDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, Guid>
{
    //public AuthenticationDbContext(DbContextOptions<AuthenticationDbContext> options)
    //    : base(options)
    //{
    //}

    public AuthenticationDbContext(DbContextOptions options)
        : base(options)
    {
    }
}
