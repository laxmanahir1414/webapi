﻿using Microsoft.AspNetCore.Identity;

namespace CSR.Budget.Authentication.Models;

public class ApplicationRole : IdentityRole<Guid>
{
    public ApplicationRole()
    {
    }

    public ApplicationRole(string roleName) : base(roleName)
    {
    }
}
