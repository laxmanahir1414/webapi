﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Linq;

public class SecureRSAEncryption
{
    // Constants for file paths
    private const string PublicKeyFile = "public_key.pem";
    private const string PrivateKeyFile = "private_key.pem";
    private const int MaxRsaEncryptSize = 214; // For 2048-bit key with OAEP padding

    public static void Main()
    {
        try
        {
            Console.WriteLine("Secure RSA Encryption/Decryption");
            Console.WriteLine("--------------------------------");

            // Generate keys if they don't exist
            if (!KeyFilesExist())
            {
                Console.WriteLine("Generating new RSA keys...");
                GenerateAndSaveKeys();
                Console.WriteLine($"Keys saved to:\n- {Path.GetFullPath(PublicKeyFile)}\n- {Path.GetFullPath(PrivateKeyFile)}");
                Console.WriteLine("WARNING: Keep private key file secure!");
            }

            while (true)
            {
                Console.WriteLine("\nOptions:");
                Console.WriteLine("1. Encrypt message");
                Console.WriteLine("2. Decrypt message");
                Console.WriteLine("3. Exit");
                Console.Write("Select option: ");

                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        HandleEncryption();
                        break;
                    case "2":
                        HandleDecryption();
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Fatal error: {ex.Message}");
            Console.WriteLine(ex.StackTrace);
        }
    }

    private static void HandleEncryption()
    {
        try
        {
            Console.Write("\nEnter message to encrypt: ");
            var message = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(message))
            {
                Console.WriteLine("Message cannot be empty.");
                return;
            }

            var encrypted = EncryptWithPublicKey(message, PublicKeyFile);
            Console.WriteLine($"\nEncrypted message (Base64):\n{encrypted}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Encryption failed: {ex.Message}");
        }
    }

    private static void HandleDecryption()
    {
        try
        {
            Console.Write("\nEnter encrypted message (Base64): ");
            var encrypted = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(encrypted))
            {
                Console.WriteLine("Encrypted message cannot be empty.");
                return;
            }

            var decrypted = DecryptWithPrivateKey(encrypted, PrivateKeyFile);
            Console.WriteLine($"\nDecrypted message:\n{decrypted}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Decryption failed: {ex.Message}");
        }
    }

    private static bool KeyFilesExist()
    {
        //GenerateAndSaveKeys();
        return File.Exists(PublicKeyFile) && File.Exists(PrivateKeyFile);
    }

    private static void GenerateAndSaveKeys()
    {
        using var rsa = RSA.Create(2048);

        // Export public key
        var publicKey = rsa.ExportSubjectPublicKeyInfo();
        File.WriteAllBytes(PublicKeyFile, publicKey);

        String a = Convert.ToBase64String(publicKey);

        // Export private key with encryption
        var privateKey = rsa.ExportEncryptedPkcs8PrivateKey(
            Encoding.UTF8.GetBytes("YourSecurePasswordHere"), // In production, get this from secure storage
            new PbeParameters(
                PbeEncryptionAlgorithm.Aes256Cbc,
                HashAlgorithmName.SHA256,
                iterationCount: 100_000));

        File.WriteAllBytes(PrivateKeyFile, privateKey);
    }

    public static string EncryptWithPublicKey(string message, string publicKeyPath)
    {
        if (string.IsNullOrWhiteSpace(message))
            throw new ArgumentException("Message cannot be empty");

        if (!File.Exists(publicKeyPath))
            throw new FileNotFoundException("Public key file not found");

        var publicKeyBytes = File.ReadAllBytes(publicKeyPath);
        var messageBytes = Encoding.UTF8.GetBytes(message);

        using var rsa = RSA.Create();
        rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);

        // For messages larger than the RSA limit, use hybrid encryption
        if (messageBytes.Length > MaxRsaEncryptSize)
        {
            return HybridEncrypt(messageBytes, rsa);
        }

        // Direct RSA encryption for small messages
        var encryptedBytes = rsa.Encrypt(messageBytes, RSAEncryptionPadding.OaepSHA256);
        return Convert.ToBase64String(encryptedBytes);
    }

    public static string DecryptWithPrivateKey(string encryptedBase64, string privateKeyPath)
    {
        if (string.IsNullOrWhiteSpace(encryptedBase64))
            throw new ArgumentException("Encrypted message cannot be empty");

        if (!File.Exists(privateKeyPath))
            throw new FileNotFoundException("Private key file not found");

        var privateKeyBytes = File.ReadAllBytes(privateKeyPath);
        var encryptedBytes = Convert.FromBase64String(encryptedBase64);

        using var rsa = RSA.Create();

        try
        {
            rsa.ImportEncryptedPkcs8PrivateKey(
                Encoding.UTF8.GetBytes("YourSecurePasswordHere"), // Same password used for encryption
                privateKeyBytes,
                out _);
        }
        catch (CryptographicException)
        {
            throw new UnauthorizedAccessException("Invalid password for private key");
        }

        // Check if this is hybrid encrypted message
        if (IsHybridEncrypted(encryptedBytes))
        {
            return HybridDecrypt(encryptedBytes, rsa);
        }

        // Direct RSA decryption
        var decryptedBytes = rsa.Decrypt(encryptedBytes, RSAEncryptionPadding.OaepSHA256);
        return Encoding.UTF8.GetString(decryptedBytes);
    }

    private static string HybridEncrypt(byte[] data, RSA rsa)
    {
        using var aes = Aes.Create();
        aes.KeySize = 256;
        aes.GenerateKey();
        aes.GenerateIV();

        // Encrypt the data with AES
        using var encryptor = aes.CreateEncryptor();
        byte[] encryptedData;
        using (var ms = new MemoryStream())
        {
            // Write IV first
            ms.Write(aes.IV, 0, aes.IV.Length);

            using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            {
                cs.Write(data, 0, data.Length);
            }
            encryptedData = ms.ToArray();
        }

        // Encrypt the AES key with RSA
        byte[] encryptedKey = rsa.Encrypt(aes.Key, RSAEncryptionPadding.OaepSHA256);

        // Combine RSA-encrypted key with AES-encrypted data
        var result = new byte[encryptedKey.Length + encryptedData.Length];
        Buffer.BlockCopy(encryptedKey, 0, result, 0, encryptedKey.Length);
        Buffer.BlockCopy(encryptedData, 0, result, encryptedKey.Length, encryptedData.Length);

        return Convert.ToBase64String(result);
    }

    private static string HybridDecrypt(byte[] combinedData, RSA rsa)
    {
        // Extract the encrypted AES key (first 256 bytes for 2048-bit RSA)
        int keySize = 256;
        byte[] encryptedKey = new byte[keySize];
        Buffer.BlockCopy(combinedData, 0, encryptedKey, 0, keySize);

        // Decrypt the AES key
        byte[] aesKey = rsa.Decrypt(encryptedKey, RSAEncryptionPadding.OaepSHA256);

        // The rest is AES-encrypted data (IV + actual data)
        byte[] encryptedData = new byte[combinedData.Length - keySize];
        Buffer.BlockCopy(combinedData, keySize, encryptedData, 0, encryptedData.Length);

        using var aes = Aes.Create();
        aes.Key = aesKey;

        // Extract IV (first 16 bytes)
        byte[] iv = new byte[16];
        Buffer.BlockCopy(encryptedData, 0, iv, 0, iv.Length);
        aes.IV = iv;

        // Decrypt the data
        using var decryptor = aes.CreateDecryptor();
        using var ms = new MemoryStream(encryptedData, iv.Length, encryptedData.Length - iv.Length);
        using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
        using var sr = new StreamReader(cs);

        return sr.ReadToEnd();
    }

    private static bool IsHybridEncrypted(byte[] data)
    {
        // Simple check - if data is larger than typical RSA output (256 bytes for 2048-bit key)
        // and not a multiple of the RSA block size
        return data.Length > 256 && data.Length % 256 != 0;
    }
}