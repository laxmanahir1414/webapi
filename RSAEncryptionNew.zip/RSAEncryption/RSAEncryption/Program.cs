﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace RsaPemExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("RSA Key Generation, PEM Export, and Encryption Demo");
            Console.WriteLine("=================================================");
            Console.WriteLine();

            try
            {
                // File paths
                string publicKeyPath = "public_key.pem";
                string privateKeyPath = "private_key.pem";

                // 1. Generate and save keys
                Console.WriteLine("Generating RSA keys (2048-bit)...");
                GenerateAndSaveKeys(publicKeyPath, privateKeyPath);
                Console.WriteLine($"Public key saved to: {Path.GetFullPath(publicKeyPath)}");
                Console.WriteLine($"Private key saved to: {Path.GetFullPath(privateKeyPath)}");
                Console.WriteLine();

                // 2. Demonstrate encryption/decryption
                Console.WriteLine("Enter a message to encrypt:");
                string originalMessage = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(originalMessage))
                {
                    originalMessage = "This is a default secret message!";
                    Console.WriteLine($"Using default message: {originalMessage}");
                }

                Console.WriteLine();
                Console.WriteLine("Encrypting with public key...");
                byte[] encryptedData = EncryptWithPublicKey(publicKeyPath, originalMessage);
                Console.WriteLine($"Encrypted data (Base64):");
                Console.WriteLine(Convert.ToBase64String(encryptedData));
                Console.WriteLine();

                Console.WriteLine("Decrypting with private key...");
                string decryptedMessage = DecryptWithPrivateKey(privateKeyPath, encryptedData);
                Console.WriteLine($"Decrypted message: {decryptedMessage}");
                Console.WriteLine();

                // Verify
                if (originalMessage == decryptedMessage)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("SUCCESS: Original and decrypted messages match!");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("ERROR: Decrypted message doesn't match original!");
                }
                Console.ResetColor();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"ERROR: {ex.Message}");
                Console.ResetColor();
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        static void GenerateAndSaveKeys(string publicKeyPath, string privateKeyPath, int keySize = 2048)
        {
            using (RSA rsa = RSA.Create(keySize))
            {
                // Save public key
                byte[] publicKeyBytes = rsa.ExportSubjectPublicKeyInfo();
                string publicKeyPem = "-----BEGIN PUBLIC KEY-----\n" +
                                     Convert.ToBase64String(publicKeyBytes, Base64FormattingOptions.InsertLineBreaks) +
                                     "\n-----END PUBLIC KEY-----";
                File.WriteAllText(publicKeyPath, publicKeyPem);

                // Save private key
                byte[] privateKeyBytes = rsa.ExportPkcs8PrivateKey();
                string privateKeyPem = "-----BEGIN PRIVATE KEY-----\n" +
                                      Convert.ToBase64String(privateKeyBytes, Base64FormattingOptions.InsertLineBreaks) +
                                      "\n-----END PRIVATE KEY-----";
                File.WriteAllText(privateKeyPath, privateKeyPem);
            }
        }

        static byte[] EncryptWithPublicKey(string publicKeyPath, string message)
        {
            string publicKeyPem = File.ReadAllText(publicKeyPath);
            using (RSA rsa = RSA.Create())
            {
                // Import public key
                publicKeyPem = publicKeyPem.Replace("-----BEGIN PUBLIC KEY-----", "")
                                          .Replace("-----END PUBLIC KEY-----", "")
                                          .Trim();
                byte[] publicKeyBytes = Convert.FromBase64String(publicKeyPem);
                rsa.ImportSubjectPublicKeyInfo(publicKeyBytes, out _);

                // Encrypt the data
                byte[] dataBytes = Encoding.UTF8.GetBytes(message);
                return rsa.Encrypt(dataBytes, RSAEncryptionPadding.OaepSHA256);
            }
        }

        static string DecryptWithPrivateKey(string privateKeyPath, byte[] encryptedData)
        {
            string privateKeyPem = File.ReadAllText(privateKeyPath);
            using (RSA rsa = RSA.Create())
            {
                // Import private key
                privateKeyPem = privateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "")
                                            .Replace("-----END PRIVATE KEY-----", "")
                                            .Trim();
                byte[] privateKeyBytes = Convert.FromBase64String(privateKeyPem);
                rsa.ImportPkcs8PrivateKey(privateKeyBytes, out _);

                // Decrypt the data
                byte[] decryptedBytes = rsa.Decrypt(encryptedData, RSAEncryptionPadding.OaepSHA256);
                return Encoding.UTF8.GetString(decryptedBytes);
            }
        }
    }
}